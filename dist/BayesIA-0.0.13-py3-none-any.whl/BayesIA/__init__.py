
from Redes import Node
from redes import BayesianNetwork
